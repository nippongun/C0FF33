﻿using System;
namespace GXPEngine
{
	public enum PickupType
	{
		Key,
		Pumpkin
	}
}
