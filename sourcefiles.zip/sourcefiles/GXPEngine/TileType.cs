﻿using System;
namespace GXPEngine
{
	public enum TileType
	{
		Background,
		Border,
		Deadly,
		Exit
	}
}
