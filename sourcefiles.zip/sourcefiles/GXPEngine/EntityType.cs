﻿using System;
namespace GXPEngine
{
	public enum EntityType
	{
		Player,
		Enemy
	}
}
