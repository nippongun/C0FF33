﻿using System;
namespace GXPEngine
{
	public struct Vector
	{
		public double _x;
		public double _y;

		public Vector(double x, double y)
		{
			this._x = x;
			this._y = y;
		}
	}
}
