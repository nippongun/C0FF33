﻿using System;
namespace GXPEngine
{
	public class Heart : Sprite
	{
		public Heart() : base( "heart.png" )
		{
			SetOrigin( 32, 32 );
		}
	}
}
