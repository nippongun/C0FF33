﻿using System;
namespace GXPEngine
{
	public class Weapon
	{
		public Weapon()
		{
		}
	}
}
